# VYRA V4

Seu dinheiro. Sua direção.

Saiba quanto você pode gastar antes do próximo salário.

## O que tem aqui

- `index.html`: o app inteiro (HTML, CSS e JavaScript juntos)
- `manifest.json`, `sw.js`, `icon*.png`, `icon.svg`: PWA instalável que funciona sem internet
- `package.json`, `capacitor.config.json`, `scripts/`, `assets/`, `.github/workflows/apk.yml`: geração do APK Android (`npm run apk`, ou automático no GitHub)
- `GUIA-ANDROID.md`: instalar no Android, testar, gerar o APK e publicar na Google Play

## Rodar no seu computador

Abra o `index.html` no navegador. Para testar a instalação e o modo offline, sirva a pasta:

    python3 -m http.server 8000

e abra http://localhost:8000 (o `localhost` conta como endereço seguro para a PWA).

## Publicar de graça

Netlify Drop: acesse https://app.netlify.com/drop e arraste a pasta `vyra` inteira (a que contém o `index.html`). Você recebe um link https. Crie uma conta grátis para o link não expirar.

Alternativas: GitHub Pages ou Cloudflare Pages.

## Como o cálculo funciona

    disponível = salário − contas − gastos − reserva
    por dia    = disponível ÷ dias até o próximo salário

- Conta paga ou pendente entra igual no cálculo. O status só organiza a lista. Não registre o pagamento de uma conta como gasto.
- Se o salário cai hoje, conta 1 dia.
- Se o disponível ficar negativo, o limite diário mostra R$ 0,00 e aparece "Déficit de R$ ...".
- Os valores são guardados em centavos (números inteiros). O limite diário é arredondado para baixo, então nunca passa do que está disponível.
- As datas usam o calendário local, sem conversão para UTC.

## Dados

Tudo fica no `localStorage` do navegador (chave `vyra:v1`). Nada é enviado a servidor. Não existe conta nem login. Trocar de aparelho ou de navegador começa do zero.

## Ao publicar uma versão nova

Troque o número em `const CACHE = 'vyra-v4'` no `sw.js` (por exemplo, `vyra-v5`) para os aparelhos pegarem a atualização.
